import React from 'react'
import BodyMain from './BodyMain'
import Footer from '../footer/Footer'

function Home() {
  return (
    <div>
     <BodyMain />
      <hr />
    </div>
  )
}

export default Home